from ..en_CA import Provider as BarcodeProvider


class Provider(BarcodeProvider):
    """Implement bank provider for ``fr_CA`` locale.

    There is no difference from the ``en_CA`` implementation.
    """

    pass
