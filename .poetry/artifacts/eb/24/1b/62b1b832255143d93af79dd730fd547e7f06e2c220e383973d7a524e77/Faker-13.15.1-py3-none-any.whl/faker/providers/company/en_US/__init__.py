from .. import Provider as CompanyProvider


class Provider(CompanyProvider):
    pass
