.. include:: ../../README.rst

.. toctree::
   :maxdepth: 2

   features
   api
   examples
   changelog
