API Reference
=============

.. automodule:: defopt
    :members:
    :undoc-members:
    :show-inheritance:
